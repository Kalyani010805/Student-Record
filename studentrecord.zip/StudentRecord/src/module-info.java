/**
 * 
 */
/**
 * 
 */
module RSAssignmentTasks {
	requires java.sql;
}