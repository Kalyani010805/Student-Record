package com.task4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

// this task is to update students marks using student id which is to be inserted by user
// and also takes new marks from the user

public class UpdateStudents {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student id: ");
		int id=sc.nextInt();
		System.out.println("Enter Student marks: ");
		int marks = sc.nextInt();
		
		
		try {
			//1.Register database
			Class.forName("com.mysql.cj.jdbc.Driver");
			//2.Creating connection object
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","01082005");
			//3.Creating Statement object : to hold query
			PreparedStatement psmt=con.prepareStatement("Update Student set marks=? where id=?");
			psmt.setInt(1, marks);
			psmt.setInt(2, id);
		    //4.Execute query : use executeUpdate()->returns no.of rows affected , use for DDL , DML queries
			int count=psmt.executeUpdate();
			System.out.println(count+" "+"Rows Updated");
			//5.Closing Connection: freeing the resources
			psmt.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
