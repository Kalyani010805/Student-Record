package com.task1;

// databse connection

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MYSQLConnection {

	public static void main(String[] args) {
	
	// Code for connecting java application with to mysql database
		
		
		try {
			//1.Register database driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//2.Creating connection object
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","01082005");
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
		System.out.println("Connection Successful");

	}

}
