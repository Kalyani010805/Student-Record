package com.task2;

// Displaying students from databse

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayStudents {

	public static void main(String[] args) {
		
		try {
			//1.Register driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//2.Create connection object
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","01082005");
			//3.Create statement object : to hold the query
			Statement stmt=con.createStatement();
			//4.Execute the hold query 
			ResultSet rs=stmt.executeQuery("select * from student");
			System.out.println("ID"+"\t"+"NAME"+"\t"+"AGE");
			while(rs.next()) {
				System.out.print(rs.getInt("id")+"\t");
				System.out.print(rs.getString("name")+"\t");
				System.out.print(rs.getInt("age")+"\n");
			}
			//closing connections: freeing up resources
			stmt.close();
			rs.close();
			con.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
