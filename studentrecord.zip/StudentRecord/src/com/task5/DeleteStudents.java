package com.task5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteStudents {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student id: ");
		int id=sc.nextInt();
		
		
		try {
			//1.Register Database Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//2.Create Connection Object
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","01082005");
			//3.Create statement object
			PreparedStatement psmt=con.prepareStatement("Delete from Student where id=?");
			psmt.setInt(1, id);
			//4.Execute Query
			int count=psmt.executeUpdate();
			System.out.println(count+" "+"Rows deleted");
			//5.Closing Connection
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}

	}

}
