package com.task3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

//Inserting students details in student table by taking input from user through console
//Insertinsg student record

public class InsertStudents {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student id: ");
		int id=sc.nextInt();
		System.out.println("Enter Student name: ");
		String name=sc.next();
		System.out.println("Enter Student age: ");
		int age=sc.nextInt();
		System.out.println("Enter Student marks: ");
		int marks=sc.nextInt();
		
		
		
		
		try {
			//1. Register database driver
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//2.Creating connection object
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root","01082005");
			
			//3.Creating statement object : to hold query here it holds insert query
			
			PreparedStatement psmt=con.prepareStatement("Insert into student values(?,?,?,?)");
			psmt.setInt(1, id);
			psmt.setString(2, name);
			psmt.setInt(3, age);
			psmt.setInt(4, marks);
			
			
			//4.Exceute query : use of exceuteUpdate() for insert query as it returns number of 
			// rows affected and executeUpdate() returns int value
			
			int count=psmt.executeUpdate();
			System.out.println(count +" "+ "Rows inserted successfully");
			//Closing connection : freeing the resources
			psmt.close();
			con.close();
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
		
			e.printStackTrace();
		}
		

	}

}
