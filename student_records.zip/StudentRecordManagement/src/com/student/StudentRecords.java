package com.student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentRecords {

	public static void main(String[] args) throws SQLException {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentsdb","root","01082005");
			System.out.println("Connection Successful\n");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int student_id;
		String name;
		String course;
		int age;
		int count;
		
		System.out.println("---------------Welcome to StudentRecord Management System---------------");
		Scanner sc=new Scanner(System.in);
		
		System.out.println("\n"+"1.Insert students record\n2.Update student records\n3.Delete student records\n4.Select all records to View\n5.Exit");
		System.out.println("\nEnter your choice: ");
		int choice=sc.nextInt();
		
		while(choice!=6) {
		switch(choice) {
		
		case 1: System.out.println("\nInsert\n");
		
		System.out.println("Enter Student id: ");
		 student_id=sc.nextInt();
		System.out.println("Enter Student name: ");
	    name=sc.next();
		System.out.println("Enter Student course: ");
		 course=sc.next();
		System.out.println("Enter Student age: ");
		 age=sc.nextInt();
		
		
		PreparedStatement stmt=con.prepareStatement("Insert into students values(?,?,?,?)");
		stmt.setInt(1, student_id);
		stmt.setString(2, name);
		stmt.setString(3, course);
		stmt.setInt(4,age);
		
	   count=stmt.executeUpdate();
		System.out.println("Rows Inserted Successfully\n");
		//con.close();
		break;
		
		case 2:System.out.println("\nUpdate\n");
		System.out.println("Enter Student id: ");
		student_id=sc.nextInt();
		System.out.println("Enter Student name: ");
		 name=sc.next();
		System.out.println("Enter Student course: ");
		 course=sc.next();
		PreparedStatement stmt1=con.prepareStatement("Update students set name=? , course=? where student_id=?");
		stmt1.setString(1, name);
		stmt1.setString(2, course);
		stmt1.setInt(3, student_id);
		
	    count=stmt1.executeUpdate();
	    System.out.println("Rows Updated Successfully\n");
	    //con.close();
	    break;
	    
		case 3:System.out.println("\nDelete record\n");
		System.out.println("Enter student id: ");
		student_id=sc.nextInt();
		PreparedStatement stmt2=con.prepareStatement("Delete from students where student_id=?");
		stmt2.setInt(1, student_id);
		
		count=stmt2.executeUpdate();
		System.out.println(count + " "+ "Rows deleted\n");
		//con.close();
		break;
		
		case 4: System.out.println("\nView all students\n");
		PreparedStatement stmt3=con.prepareStatement("Select * from students");
		ResultSet rs=stmt3.executeQuery();
		System.out.println("STUDENT_ID\t\tNAME\t\tCOURSE\t\tAGE");
		while(rs.next()) {
			System.out.print(rs.getInt("student_id")+"\t\t\t");
			System.out.print(rs.getString("name")+"\t\t");
			System.out.print(rs.getString("course")+"\t\t");
			System.out.println(rs.getInt("age"));
		}
		
		//con.close();
		break;
		
		
		case 5: System.out.println("Thanks for Visiting...");
		System.exit(0);
		break;
		
		default:
			System.out.println("Please enter valid choice");
			break;
		
		
		
		
		}
		System.out.println("Enter your next choice: ");
		choice=sc.nextInt();
		}
		con.close();

	}

}
