/**
 * 
 */
/**
 * 
 */
module StudentRecordManagement {
	requires java.sql;
}